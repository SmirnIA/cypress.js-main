# cypress.js
Автотесты на cypress
